package com.example.spring_security.entity.enums;

public enum TokenType {
  BEARER
}
